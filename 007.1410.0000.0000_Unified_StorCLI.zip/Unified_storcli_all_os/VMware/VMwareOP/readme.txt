
1. All the installed VIB Packages can be listed using below command.
   Command:esxcli software vib list 
	
2. The StorCLI VIB Package can be installed using the below syntax
	Syntax:esxcli software vib install -v=<Filepath of the StorCLI VIB>
    
3.The VIB Package can be removed using the below syntax
	Syntax:esxcli software vib remove -n=<VIB Name of StorCLI>

Note : This binary is for versions from ESXi6.0 to ESXi6.7.