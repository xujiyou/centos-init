THIS IS A OPEN POWER PC LITTLE ENDIAN DISTRIBUTION FOR 64 BIT MACHINES 

To run StorCLI, perform any one of the following steps:
1. Unzip the StorCLI package.
2. Install .deb package.

