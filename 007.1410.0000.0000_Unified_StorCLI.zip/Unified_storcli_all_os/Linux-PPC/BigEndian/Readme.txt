THIS IS A OPEN POWER PC BIG ENDIAN DISTRIBUTION

Unzip the StorCLI package and execute the storcli binary.



