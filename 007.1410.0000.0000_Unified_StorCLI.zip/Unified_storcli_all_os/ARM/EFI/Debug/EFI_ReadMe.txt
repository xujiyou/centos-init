To execute StorCLI, perform the following steps:

1. From the boot menu, choose EFI Shell.
2. Goto the folder containing the StorCLI EFI binaries.
3. Execute StorCLI binaries.
