To install StorCLI RPMs, perform the following steps:

1. Unzip the StorCLI package.
2. To install the StorCLI RPM, run the rpm -ivh <StorCLI-x.xx-x.aarch64.rpm> command.
3. To upgrade the StorCLI RPM, run the rpm -Uvh <StorCLI-x.xx-x.aarch64.rpm> command.

To install StorCLI DEB package, perform the following steps:

1. Installing debian Package
	sudo dpkg -i storcli_1.0_arm64.deb

2. verifying , if the package is installed successfully or not.
   dpkg -l | grep -i storcli

3. Run the commands with super user as below.
	sudo /opt/MegaRAID/storcli/storcli show ctrlcount
