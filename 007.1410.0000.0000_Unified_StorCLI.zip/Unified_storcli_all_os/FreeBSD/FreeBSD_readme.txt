Requirement for StorCli & StorCli64 Execution in FreeBSD OS:

======================================================
In FreeBSD OS, StorCli or StorCli64 application will not function if the user is trying to run it in CSH, the default shell in FreeBSD.
Please ensure that the user has entered the bash shell by executing the command "bash".